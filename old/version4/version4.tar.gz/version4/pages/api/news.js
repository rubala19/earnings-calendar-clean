import { getServerSession } from "next-auth/next";
import { authOptions } from "./auth/[...nextauth]";

const DEBUG = (process.env.DEBUG_LOGS === 'true');
function dbg(...args) { if (DEBUG) console.log(...args); }

// Normalize various date formats to ISO string
// Handles: ISO strings, Alpha Vantage format (20260420T143000), Unix timestamps
function normalizeDate(raw) {
  if (!raw) return null;
  // Alpha Vantage: 20260420T143000
  if (typeof raw === 'string' && /^\d{8}T\d{6}$/.test(raw)) {
    const d = raw.replace(
      /^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})$/,
      '$1-$2-$3T$4:$5:$6Z'
    );
    return d;
  }
  // Unix timestamp (number)
  if (typeof raw === 'number') return new Date(raw * 1000).toISOString();
  // Already ISO or parseable string
  const d = new Date(raw);
  return isNaN(d) ? null : d.toISOString();
}

// FIX #5: Improved sentiment analysis.
// - Removed neutral/ambiguous words like "revenue" and "up"/"down" that
//   fire too broadly and skew scores regardless of actual sentiment context.
// - Threshold tuned to reduce false positives on short headlines.
function analyzeSentiment(text) {
  const lowerText = text.toLowerCase();

  const positiveWords = [
    'profit', 'gain', 'growth', 'surge', 'jump', 'rally', 'beat', 'exceed',
    'strong', 'boost', 'rise', 'climb', 'soar', 'bullish', 'upgrade',
    'record high', 'success', 'outperform', 'innovative', 'breakthrough',
    'improved', 'optimistic', 'confident', 'advance', 'milestone',
    'achieve', 'expand', 'earnings beat', 'raised guidance', 'buyback'
  ];

  const negativeWords = [
    'loss', 'fall', 'drop', 'decline', 'plunge', 'miss', 'weak', 'worry',
    'concern', 'bearish', 'cut', 'downgrade', 'risk', 'fail', 'worst',
    'lawsuit', 'investigation', 'warning', 'decrease', 'disappointing',
    'missed', 'below expectations', 'slump', 'crash', 'trouble', 'crisis',
    'layoff', 'bankruptcy', 'debt', 'losses', 'recall', 'fraud', 'penalty'
  ];

  let score = 0;
  let positiveCount = 0;
  let negativeCount = 0;

  positiveWords.forEach(word => {
    // Use word boundary for single words, substring match for phrases
    const pattern = word.includes(' ')
      ? word
      : `\\b${word}\\b`;
    const regex = new RegExp(pattern, 'gi');
    const matches = lowerText.match(regex);
    if (matches) {
      positiveCount += matches.length;
      score += matches.length;
    }
  });

  negativeWords.forEach(word => {
    const pattern = word.includes(' ')
      ? word
      : `\\b${word}\\b`;
    const regex = new RegExp(pattern, 'gi');
    const matches = lowerText.match(regex);
    if (matches) {
      negativeCount += matches.length;
      score -= matches.length;
    }
  });

  dbg('[sentiment]', { positiveCount, negativeCount, score });

  // Normalize to -1 to 1 scale
  const normalizedScore = Math.max(-1, Math.min(1, score / 3));

  // FIX #5: Raised threshold slightly to reduce false positives on short text
  let sentiment = 'neutral';
  if (normalizedScore > 0.2) sentiment = 'positive';
  else if (normalizedScore < -0.2) sentiment = 'negative';

  return {
    score: normalizedScore,
    sentiment,
    details: { positiveCount, negativeCount }
  };
}

// Alpha Vantage News (has built-in sentiment)
async function fetchFromAlphaVantage(ticker) {
  const API_KEY = process.env.ALPHAVANTAGE_KEY;
  if (!API_KEY) {
    dbg('[news] No ALPHAVANTAGE_KEY');
    return null;
  }

  const url = `https://www.alphavantage.co/query?function=NEWS_SENTIMENT&tickers=${ticker}&limit=5&apikey=${API_KEY}`;

  try {
    const response = await fetch(url);
    if (!response.ok) return null;

    const data = await response.json();

    if (data.feed && Array.isArray(data.feed) && data.feed.length > 0) {
      const news = data.feed.map(item => {
        const tickerSentiment = item.ticker_sentiment?.find(ts => ts.ticker === ticker);
        let sentimentScore = 0;
        let sentiment = 'neutral';

        if (tickerSentiment) {
          sentimentScore = parseFloat(tickerSentiment.ticker_sentiment_score) || 0;
          sentiment = tickerSentiment.ticker_sentiment_label?.toLowerCase() || 'neutral';
        }

        return {
          headline: item.title,
          summary: item.summary,
          url: item.url,
          source: item.source,
          publishedAt: normalizeDate(item.time_published),
          sentiment,
          sentimentScore
        };
      });

      return news;
    }

    return null;
  } catch (err) {
    dbg('[news] Alpha Vantage error:', err.message);
    return null;
  }
}

// Finnhub News
async function fetchFromFinnhub(ticker) {
  const API_KEY = process.env.FINNHUB_API_KEY;
  if (!API_KEY) {
    dbg('[news] No FINNHUB_API_KEY');
    return null;
  }

  const today = new Date();
  const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
  const fromDate = weekAgo.toISOString().split('T')[0];
  const toDate = today.toISOString().split('T')[0];

  const url = `https://finnhub.io/api/v1/company-news?symbol=${ticker}&from=${fromDate}&to=${toDate}&token=${API_KEY}`;

  try {
    const response = await fetch(url);
    if (!response.ok) return null;

    const data = await response.json();

    if (Array.isArray(data) && data.length > 0) {
      const news = data.slice(0, 5).map(item => {
        const text = `${item.headline} ${item.summary}`;
        const analysis = analyzeSentiment(text);

        return {
          headline: item.headline,
          summary: item.summary,
          url: item.url,
          source: item.source,
          publishedAt: new Date(item.datetime * 1000).toISOString(),
          sentiment: analysis.sentiment,
          sentimentScore: analysis.score
        };
      });

      return news;
    }

    return null;
  } catch (err) {
    dbg('[news] Finnhub error:', err.message);
    return null;
  }
}

// Financial Modeling Prep News
async function fetchFromFMP(ticker) {
  const API_KEY = process.env.FMP_API_KEY;
  if (!API_KEY) {
    dbg('[news] No FMP_API_KEY');
    return null;
  }

  const url = `https://financialmodelingprep.com/api/v3/stock_news?tickers=${ticker}&limit=5&apikey=${API_KEY}`;

  try {
    const response = await fetch(url);
    if (!response.ok) return null;

    const data = await response.json();

    if (Array.isArray(data) && data.length > 0) {
      const news = data.map(item => {
        const text = `${item.title} ${item.text}`;
        const analysis = analyzeSentiment(text);

        return {
          headline: item.title,
          summary: item.text,
          url: item.url,
          source: item.site,
          publishedAt: normalizeDate(item.publishedDate),
          sentiment: analysis.sentiment,
          sentimentScore: analysis.score
        };
      });

      return news;
    }

    return null;
  } catch (err) {
    dbg('[news] FMP error:', err.message);
    return null;
  }
}

// FIX #7: Yahoo — use a separate summary field rather than repeating the title.
// The Yahoo search endpoint doesn't provide a full article summary, so we
// set summary to null and the UI will skip rendering it when absent.
async function fetchFromYahoo(ticker) {
  const url = `https://query2.finance.yahoo.com/v1/finance/search?q=${ticker}&newsCount=5`;

  try {
    const response = await fetch(url);
    if (!response.ok) return null;

    const data = await response.json();

    if (data.news && Array.isArray(data.news) && data.news.length > 0) {
      const news = data.news.slice(0, 5).map(item => {
        const analysis = analyzeSentiment(item.title);

        return {
          headline: item.title,
          summary: null, // FIX #7: Yahoo doesn't provide summaries; don't duplicate headline
          url: item.link,
          source: item.publisher,
          publishedAt: new Date(item.providerPublishTime * 1000).toISOString(),
          sentiment: analysis.sentiment,
          sentimentScore: analysis.score
        };
      });

      return news;
    }

    return null;
  } catch (err) {
    dbg('[news] Yahoo error:', err.message);
    return null;
  }
}

export default async function handler(req, res) {
  // FIX #1: Require authentication
  const session = await getServerSession(req, res, authOptions);
  if (!session) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { symbol } = req.query;

  if (!symbol) {
    return res.status(400).json({ error: 'Missing symbol parameter' });
  }

  const ticker = symbol.toUpperCase();
  dbg('[news] Fetching news for:', ticker);

  try {
    const sources = [
      fetchFromAlphaVantage,
      fetchFromFinnhub,
      fetchFromFMP,
      fetchFromYahoo
    ];

    for (const fetchFn of sources) {
      try {
        const news = await fetchFn(ticker);
        if (news && news.length > 0) {
          dbg('[news] Success, found', news.length, 'articles');
          return res.status(200).json({ news });
        }
      } catch (err) {
        dbg('[news] Source failed:', err.message);
        continue;
      }
    }

    return res.status(200).json({ news: [] });

  } catch (error) {
    console.error('[news] Error:', error.message);
    return res.status(500).json({
      error: error.message || 'Failed to fetch news'
    });
  }
}
